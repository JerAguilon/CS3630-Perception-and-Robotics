#!/usr/bin/env python

import numpy as np
import re
from sklearn import svm, metrics, model_selection, externals
from skimage import io, feature, filters, exposure, color
import pickle

class ImageClassifier:

    def __init__(self):
        self.classifer = None

    def imread_convert(self, f):
        return io.imread(f).astype(np.uint8)

    def load_data_from_folder(self, dir):
        # read all images into an image collection
        ic = io.ImageCollection(dir+"*.bmp", load_func=self.imread_convert)

        #create one large array of image data
        data = io.concatenate_images(ic)

        #extract labels from image names
        labels = np.array(ic.files)
        for i, f in enumerate(labels):
            m = re.search("_", f)
            labels[i] = f[len(dir):m.start()]

        return(data,labels)

    def extract_image_features(self, data):
        l = []
        for im in data:
            im_gray = color.rgb2gray(im)

            im_gray = filters.gaussian(im_gray, sigma=0.4)

            f = feature.hog(im_gray, orientations=10, pixels_per_cell=(48, 48), cells_per_block=(4, 4), feature_vector=True, block_norm='L2-Hys')
            l.append(f)


        feature_data = np.array(l)
        return(feature_data)

    def train_classifier(self, train_data, train_labels):
        self.classifer = svm.LinearSVC()
        self.classifer.fit(train_data, train_labels)

    def predict_labels(self, data):
        predicted_labels = self.classifer.predict(data)
        return predicted_labels


def main():

    img_clf = ImageClassifier()

    # load images
    filepaths = ['./Fall2018ClassImages/drone/','./Fall2018ClassImages/order/','./Fall2018ClassImages/inspection/', './Fall2018ClassImages/none/' ]
    data_set = []
    labels = []
    for filename in filepaths:
        (data_raw, data_labels) = img_clf.load_data_from_folder(filename)
        feature_data = img_clf.extract_image_features(data_raw)
        data_set.append(feature_data)
        labels.append(data_labels)

    data = np.vstack(data_set)
    labels = np.concatenate(labels, axis=0)
    X_train, X_test, y_train, y_test = model_selection.train_test_split(data, labels, test_size=0.2, train_size=0.8)
    img_clf.train_classifier(X_train, y_train.T)
    # (train_raw, train_labels) = img_clf.load_data_from_folder('./train/')
    # (test_raw, test_labels) = img_clf.load_data_from_folder('./test/')

    # convert images into features
    # train_data = img_clf.extract_image_features(train_raw)
    # test_data = img_clf.extract_image_features(test_raw)

    # # train model
    # img_clf.train_classifier(train_data, train_labels)
    predicted_labels = img_clf.predict_labels(X_train)
    print("\nTraining results")
    print("=============================")
    print("Confusion Matrix:\n",metrics.confusion_matrix(y_train, predicted_labels))
    print("Accuracy: ", metrics.accuracy_score(y_train, predicted_labels))
    print("F1 score: ", metrics.f1_score(y_train, predicted_labels, average='micro'))

    # test model
    predicted_labels = img_clf.predict_labels(X_test)
    print("\nTest results")
    print("=============================")
    print("Confusion Matrix:\n",metrics.confusion_matrix(y_test, predicted_labels))
    print("Accuracy: ", metrics.accuracy_score(y_test, predicted_labels))
    print("F1 score: ", metrics.f1_score(y_test, predicted_labels, average='micro'))
    #externals.joblib.dump(img_clf.classifer, 'model.pkl')
    with open('model.pkl', 'wb') as pickle_file:
        pickle.dump(img_clf, pickle_file)


if __name__ == "__main__":
    main()
