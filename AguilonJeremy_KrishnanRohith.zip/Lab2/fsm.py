##Created by Jeremy Aguilon and Rohith Krishnan
import sys
import cozmo
import numpy as np
import pickle
import time
from sklearn import model_selection
from sklearn.externals import joblib
from Lab1_Soln import ImageClassifier
import pickle

class RobotState:
    IDLE = 0
    DRONE = 1
    ORDER = 2
    INSPECTION = 3
    TERMINAL = 4

img_classifier = None
with open('model.pkl', 'rb') as pickle_file:
    img_classifier = pickle.load(pickle_file)


def run(sdk_conn):
    robot = sdk_conn.wait_for_robot()
    robot.camera.image_stream_enabled = True
    robot.camera.color_image_enabled = False
    robot.camera.enable_auto_exposure()

    robot_state = RobotState.IDLE
    ##loading trained model
    while robot_state != RobotState.TERMINAL:
        if robot_state == RobotState.IDLE:
            ##monitor image stream and classify it using
            ##Lab 1 classifier
            votes = {}
            curr_rotate = 10

            rotations = [0, 10, -20, 10]
            for i in range(4):
                robot.turn_in_place(cozmo.util.degrees(rotations[i])).wait_for_completed()

                latest_image = robot.world.latest_image
                if latest_image is not None:
                    raw_image = latest_image.raw_image
                    if raw_image is not None:
                        raw_image = np.array(raw_image)
                        image_features = img_classifier.extract_image_features([raw_image])
                        label = img_classifier.predict_labels(image_features)[0]

                        if label in votes:
                            votes[label] += 1
                        elif label == 'none':
                            votes[label] = 0 # downweight 'none' labels
                        else:
                            votes[label] = 1
                curr_rotate = -curr_rotate
            print("VOTES: {}".format(votes))
            best_choice = max([(vote, label) for label, vote in votes.items()])
            label = best_choice[1]

            print(label)
            robot.say_text(label).wait_for_completed()
            if label == "drone":
                robot_state = RobotState.DRONE
            elif label == "order":
                robot_state = RobotState.ORDER
            elif label == "inspection":
                robot_state = RobotState.INSPECTION
            else:
                robot_state = RobotState.IDLE

            # robot_state = RobotState.DRONE
        elif robot_state == RobotState.DRONE:
            ##locate cube, pick it up, drive forward with cube for 10cm,
            ## put it down
            look_around = robot.start_behavior(cozmo.behavior.BehaviorTypes.LookAroundInPlace)

            found_cube = None

            try:
                found_cube = robot.world.wait_for_observed_light_cube(timeout=None)
                print("Found a cube: {}".format(found_cube))
            except Exception as e:
                print("Error finding cube: {}".format(e))
            finally:
                look_around.stop()

            found_cube.set_lights(cozmo.lights.green_light.flash())

            # Pick up the object
            action = robot.pickup_object(found_cube, num_retries=4)
            action.wait_for_completed(timeout=None)
            if action.has_failed:
                code, reason = action.failure_reason
                result = action.result
                print("Pickup Cube failed: code=%s reason=%s result=%s" % (code, reason, result))

            # TODO: Move forward 10 cm
            action = robot.drive_straight(distance=cozmo.util.Distance(distance_mm=100), speed=cozmo.util.Speed(speed_mmps=20))
            action.wait_for_completed(timeout=None)
            if action.has_failed:
                code, reason = action.failure_reason
                result = action.result
                print("Pickup Cube failed: code=%s reason=%s result=%s" % (code, reason, result))


            # Place the object back down
            action = robot.place_object_on_ground_here(found_cube)
            action.wait_for_completed(timeout=None)
            if action.has_failed:
                code, reason = action.failure_reason
                result = action.result
                print("Pickup Cube failed: code=%s reason=%s result=%s" % (code, reason, result))


            found_cube.set_light_corners(None, None, None, None)

            # TODO: Move backward 10 cm
            action = robot.drive_straight(distance=cozmo.util.Distance(distance_mm=-100), speed=cozmo.util.Speed(speed_mmps=20))
            action.wait_for_completed(timeout=None)
            if action.has_failed:
                code, reason = action.failure_reason
                result = action.result
                print("Pickup Cube failed: code=%s reason=%s result=%s" % (code, reason, result))

            robot_state = RobotState.IDLE
        elif robot_state == RobotState.ORDER:
            ##drive in circle with radicus 10cm
            drive = robot.drive_wheels(l_wheel_speed=15, r_wheel_speed=80, duration=9)
            robot_state = RobotState.IDLE
        elif robot_state == RobotState.INSPECTION:
            robot_state = RobotState.IDLE
            ##drive in 20X20 cm square, continuously lower and raise arms

            for _ in range(4):
                drive = robot.drive_straight(cozmo.util.distance_mm(200), cozmo.util.speed_mmps(50))
                robot.set_lift_height(1.0, duration=2.0, in_parallel=True).wait_for_completed()
                robot.set_lift_height(0.0, duration=2.0, in_parallel=True).wait_for_completed()
                drive.wait_for_completed()

                turn = robot.turn_in_place(cozmo.util.degrees(90))
                turn.wait_for_completed()

            robot_state = RobotState.IDLE


def main():
    cozmo.setup_basic_logging()
    try:
        cozmo.connect(run)
    except cozmo.ConnectionError as e:
        sys.exit("A connection error occurred: %s" % e)

if __name__ == '__main__':
    main()
